﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using DG.Tweening;

public class RotationObject : MonoBehaviour {

	// Use this for initialization
	void Start () {
	}
	
	// Update is called once per frame
	void Update()
	{
		//transform.Rotate (Vector3.forward * -90* Time.deltaTime);
	}

	void Rotate() {
		
	}
}
